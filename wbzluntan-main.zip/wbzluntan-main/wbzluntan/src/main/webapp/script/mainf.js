$(document).ready(function() {
    $("#jumpbtn").click(function() {
        window.location.href = "/wbzluntan/login.html";
    })
});

$(document).ready(function() {
    $("#zhubtn").click(function() {
        window.location.href = "/wbzluntan/register.html";
    })
});